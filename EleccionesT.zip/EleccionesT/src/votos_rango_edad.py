from enum import Enum, auto

class Edad(Enum):
    """
    Enumeradores para los rangos de edad.
    """
    

class Genero(Enum):
    """
    Enumeradores para género.
    """
    

class VotosRangoEdad:
    """
    Votos de un rango de edad.
    """

    def __init__(self, edad: Edad):
        """
        Crea los votos en un rango de edad.
        La cantidad de votos del género masculino y femenino se inicializan en 0.
        """
        

    def dar_cantidad_masculino(self) -> int:
        """
        Retorna la cantidad de votos de personas con género masculino.
        """
        

    def dar_cantidad_femenino(self) -> int:
        """
        Retorna la cantidad de votos de personas con género femenino.
        """
        

    def dar_edad(self) -> Edad:
        """
        Retorna la edad del rango.
        """
        

    def dar_cantidad_total_votos(self) -> int:
        """
        Retorna la cantidad total de votos.
        """
        

    def registrar_voto(self, genero: Genero):
        """
        Registra un voto al género dado por parámetro.
        """
        

    def reiniciar(self):
        """
        Reinicia el conteo de votos.
        """
        
