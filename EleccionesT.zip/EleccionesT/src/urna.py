from candidato import Candidato, Medio
from votos_rango_edad import Edad, Genero


class Urna:
    def __init__(self):
        
    def dar_candidato1(self):

    def dar_candidato2(self):

    def dar_candidato3(self):

    def buscar_candidato(self, numero):

    def calcular_total_votos(self):

    def calcular_total_votos_genero_femenino(self):

    def calcular_total_votos_genero_masculino(self):

    def dar_total_votos_rango_edad(self, edad):

    def calcular_costo_promedio_campanha(self):

    def calcular_porcentaje_votos_candidato(self, numero):
        
    def registrar_voto(self, numero, edad, genero, medio):

    def reiniciar(self):

    # Métodos de extensión
    def metodo1(self):
        return "Respuesta 1"

    def metodo2(self):
        return "Respuesta 2"
